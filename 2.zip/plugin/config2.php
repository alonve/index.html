<?php 
//用于判断会员模板
include("../config.php");
if($tencent=='true'){
	include_once("txprotect.php");
}
?>